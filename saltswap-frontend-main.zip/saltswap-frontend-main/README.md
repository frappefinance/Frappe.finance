# 🧂 SaltSwap Frontend

[![Netlify Status](https://api.netlify.com/api/v1/badges/66319811-32db-485e-ae07-ae9431b16f46/deploy-status)](https://app.netlify.com/sites/naughty-goodall-df47f6/deploys)

This project contains the main features of the SaltSwap application.

If you want to contribute, please refer to the [contributing guidelines](./CONTRIBUTING.md) of this project.
