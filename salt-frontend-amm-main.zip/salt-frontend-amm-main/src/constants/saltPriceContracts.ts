const priceContracts: { saltAddress: string, busdAddress: string, lpAddress: string } = {
  saltAddress: '0x2849b1aE7E04A3D9Bc288673A92477CF63F28aF4',
  busdAddress: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
  lpAddress: '0x6596f770786915556C47E301cC8290aa14288d99'
}

export default priceContracts